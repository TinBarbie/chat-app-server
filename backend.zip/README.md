This repository was just developed in dev mode for interview purpose, no deployment yet.

Steps to start the server:

1. Create a collection with database name and password
2. Change settings for database information in **config/config.json** (development object)
3. Run **npm install** to install all packages
4. Run **npm run dev** to start the server
